package ONETOMANY.onetomany_maven;

import java.util.ArrayList;
import java.util.List;

import ONETOMANY.onetomany_maven.dao.Associationdao;
import ONETOMANY.onetomany_maven.dto.ADDRESS;
import ONETOMANY.onetomany_maven.dto.PERSONS;

public class App 
{
    public static void main( String[] args )
    {
    	
    	 Associationdao dao=new Associationdao();
        ADDRESS address=new ADDRESS();
        address.setCity("salem");
        address.setPincod("560021");
        address.setType("perment");
        
        ADDRESS address1=new ADDRESS();
        address1.setCity("salem");
        address1.setPincod("560021");
        address1.setType("perment");
        
        ADDRESS address2=new ADDRESS();
        address2.setCity("salem");
        address2.setPincod("560021");
        address2.setType("perment");
        
        List<ADDRESS> list=new ArrayList<ADDRESS>();
        list.add(address);
        list.add(address1);
        list.add(address2);
        
        PERSONS persons=new PERSONS();
        persons.setEmail("inba@gmail.com");
        persons.setName("inba");
        persons.setAddress(list);
        dao.savepersonsDeatails(persons);
        
    }
}
