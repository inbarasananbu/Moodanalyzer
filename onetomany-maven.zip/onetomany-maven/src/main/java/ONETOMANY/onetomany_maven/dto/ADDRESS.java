package ONETOMANY.onetomany_maven.dto;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
@Entity
@Table(name="address")
public class ADDRESS implements Serializable {
	@Id
	@GenericGenerator(name="auto",strategy="increment")
	@GeneratedValue(generator="auto")
	@Column(name="id")
	private long id;
	@Column(name="city")
	private String city;
	@Column(name="type")
	private String type;
	@Column(name="pincod")
	private String pincod;
	public ADDRESS() {
		
	}
	@Override
	public String toString() {
		return "ADDRESS [id=" + id + ", city=" + city + ", type=" + type + ", pincod=" + pincod + "]";
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getPincod() {
		return pincod;
	}
	public void setPincod(String pincod) {
		this.pincod = pincod;
	}

}
